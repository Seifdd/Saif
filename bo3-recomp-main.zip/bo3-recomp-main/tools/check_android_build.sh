#!/usr/bin/env bash
# Checks, before a full Android build, that everything it needs is in place, and says what is missing.
# Usage: tools/check_android_build.sh          (exit 0 = ready, 1 = something is missing)
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
ok=1
good() { printf '  [ok]      %s\n' "$1"; }
bad()  { printf '  [MISSING] %s\n            -> %s\n' "$1" "$2"; ok=0; }

echo "Host tools"
for c in git cmake ninja clang clang++ python3 zip unzip; do
    if command -v "$c" >/dev/null 2>&1; then good "$c"; else bad "$c" "install it (Fedora: sudo dnf install clang cmake ninja-build git python3 zip unzip)"; fi
done
if python3 -c "import zstandard" >/dev/null 2>&1; then good "python3 zstandard"; else bad "python3 zstandard" "pip install zstandard (or: sudo dnf install python3-zstandard)"; fi
if command -v javac >/dev/null 2>&1; then good "javac"; else bad "javac" "install a JDK 17 (sudo dnf install java-17-openjdk-devel)"; fi

echo "Android SDK / NDK"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Android/Sdk}}"
if [ -d "$SDK/platforms" ]; then good "SDK at $SDK"; else bad "Android SDK" "set ANDROID_HOME to the SDK folder (Android Studio > SDK Manager)"; fi
NDK="$SDK/ndk/29.0.14206865"
if [ -f "$NDK/build/cmake/android.toolchain.cmake" ]; then good "NDK 29.0.14206865"; else bad "NDK 29.0.14206865" "SDK Manager > SDK Tools > NDK (Side by side) 29.0.14206865"; fi
if [ -n "$(ls -d "$SDK"/build-tools/*/ 2>/dev/null | head -1)" ]; then good "build-tools"; else bad "build-tools" "SDK Manager > SDK Platforms/Tools > Android SDK Build-Tools"; fi
if [ -f "$SDK/platforms/android-35/android.jar" ]; then good "platform android-35"; else bad "platform android-35" "SDK Manager > SDK Platforms > Android 15 (API 35)"; fi

echo "Game files (your own copy, never committed)"
if [ -f "BKU-Call of Duty - Black Ops III.zar" ]; then good "disc image (.zar) in the repository folder"; else bad "disc image" "copy your BKU-Call of Duty - Black Ops III.zar into $ROOT"; fi
if [ -f "extracted/game/default.xex" ]; then good "extracted game (prepare.sh step 1 done)"; else bad "extracted game" "run tools/prepare.sh (needs the .zar above)"; fi

echo "Third-party sources and native libraries"
if [ -d thirdparty/SDL3 ]; then good "thirdparty sources"; else bad "thirdparty sources" "run tools/fetch_deps.sh"; fi
if [ -f thirdparty/ffmpeg-android/lib/libavcodec.so ]; then good "FFmpeg for Android"; else bad "FFmpeg for Android" "run tools/build_ffmpeg_android.sh"; fi
if [ -f thirdparty/turnip-android/libvulkan_freedreno.so ]; then good "Turnip driver"; else bad "Turnip driver" "run tools/build_turnip_android.sh"; fi
for so in libbo3_zm.so libbo3_mp.so libbo3_setup.so; do
    if [ -f "build-android/$so" ]; then good "$so"; else bad "$so" "cmake --build build-android --target bo3_zm bo3_mp bo3_setup"; fi
done

echo
if [ "$ok" = 1 ]; then echo "READY: run tools/package_android.sh"; exit 0; fi
echo "NOT READY: fix the items marked MISSING, in the order listed."; exit 1
