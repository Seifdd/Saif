package com.bo3recomp;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

// The app's start screen: choose Multiplayer or Zombies, add game files (update / DLC), settings and the
// language (System default / Arabic / English). The games themselves still run in their own processes
// (ZombiesActivity / MultiplayerActivity); they send the player to the installer when nothing is installed.
public class HomeActivity extends Activity {
    static final int BG = OptionsPanel.BG, CARD = OptionsPanel.CARD, LINE = OptionsPanel.LINE, TEXT = OptionsPanel.TEXT,
        SUB = OptionsPanel.SUB, ACCENT = OptionsPanel.ACCENT, OK = OptionsPanel.OK;

    int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    GradientDrawable round(int color, float r, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
    }

    // rebuilt every time the screen comes back: the language and the "installed" state may have changed
    @Override protected void onResume() {
        super.onResume();
        build();
    }

    void build() {
        Lang.init(this);
        boolean installed = Installer.isInstalled(this);
        ScrollView sv = new ScrollView(this);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[] { Color.rgb(28, 20, 16), BG, BG }));
        LinearLayout outer = new LinearLayout(this);
        outer.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(20), dp(28), dp(20), dp(28));
        outer.addView(col, new LinearLayout.LayoutParams(Math.min(getResources().getDisplayMetrics().widthPixels, dp(640)), ViewGroup.LayoutParams.WRAP_CONTENT));
        sv.addView(outer);

        // header + language switch
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout ht = new LinearLayout(this);
        ht.setOrientation(LinearLayout.VERTICAL);
        TextView kicker = text("BO3 RECOMP", 12, ACCENT, true);
        kicker.setLetterSpacing(0.12f);
        ht.addView(kicker);
        TextView title = text(Lang.t("home_sub"), 26, TEXT, true);
        ht.addView(title);
        head.addView(ht, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        col.addView(head);
        col.addView(langRow(), spaced(14));

        // the two games
        col.addView(modeCard("zm", R.mipmap.ic_zm, Lang.t("mode_zm"), Lang.t("mode_zm_sub")), spaced(18));
        col.addView(modeCard("mp", R.mipmap.ic_mp, Lang.t("mode_mp"), Lang.t("mode_mp_sub")), spaced(12));

        // files / update / DLC and settings
        col.addView(smallCard(Lang.t("files_btn"), installed ? Lang.t("files_ok") : Lang.t("files_need"), installed ? OK : ACCENT, v ->
            startActivity(new Intent(this, InstallerActivity.class).putExtra("manage", true))), spaced(18));
        col.addView(smallCard(Lang.t("settings_btn"), Lang.t("settings_sub"), SUB, v ->
            startActivity(new Intent(this, SettingsActivity.class))), spaced(10));

        Lang.apply(sv);
        setContentView(sv);
    }

    LinearLayout.LayoutParams spaced(int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(topDp);
        return lp;
    }

    View langRow() {
        LinearLayout row = new LinearLayout(this);
        for (int i = 0; i < Lang.CODES.length; i++) {
            final int k = i;
            boolean on = i == Lang.index();
            TextView c = text(Lang.t(Lang.NAME_KEYS[i]), 14, on ? Color.WHITE : TEXT, true);
            c.setGravity(Gravity.CENTER);
            c.setPadding(dp(6), dp(9), dp(6), dp(9));
            c.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.argb(60, 255, 255, 255)),
                on ? round(ACCENT, 20, 0) : round(Color.rgb(34, 38, 45), 20, LINE), round(Color.WHITE, 20, 0)));
            c.setOnClickListener(v -> { Lang.set(this, k); build(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMarginEnd(dp(6));
            row.addView(c, lp);
        }
        return row;
    }

    View modeCard(final String mode, int icon, String name, String sub) {
        LinearLayout c = new LinearLayout(this);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setPadding(dp(18), dp(18), dp(18), dp(18));
        c.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.argb(60, 255, 255, 255)), round(CARD, 18, LINE), round(Color.WHITE, 18, 0)));
        ImageView iv = new ImageView(this);
        iv.setImageResource(icon);
        c.addView(iv, new LinearLayout.LayoutParams(dp(64), dp(64)));
        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        tx.setPadding(dp(16), 0, dp(16), 0);
        tx.addView(text(name, 24, TEXT, true));
        tx.addView(text(sub, 14, SUB, false));
        c.addView(tx, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView go = text(Lang.rtl() ? "\u2039" : "\u203a", 30, ACCENT, true);
        c.addView(go);
        c.setClickable(true);
        c.setOnClickListener(v -> play(mode));
        return c;
    }

    View smallCard(String title, String sub, int subColor, View.OnClickListener click) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.argb(60, 255, 255, 255)), round(CARD, 16, LINE), round(Color.WHITE, 16, 0)));
        c.addView(text(title, 17, TEXT, true));
        c.addView(text(sub, 13, subColor, false));
        c.setClickable(true);
        c.setOnClickListener(click);
        return c;
    }

    void play(String mode) {
        if (!Installer.isInstalled(this)) {
            startActivity(new Intent(this, InstallerActivity.class).putExtra("mode", mode));
            return;
        }
        startActivity(new Intent(this, GameStart.activityFor(mode)));
    }
}
