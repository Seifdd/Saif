package com.bo3recomp;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.view.View;

import java.util.Locale;

// Interface language: "System default" (the phone's language; Arabic if it is Arabic, English otherwise),
// Arabic or English. All texts are in res/values/strings.xml (English) and res/values-ar/strings.xml (Arabic);
// the choice is saved in SharedPreferences "lang".
//
// Every process (launcher, Zombies, Multiplayer) calls init() before it shows text, because the game
// activities run in their own processes and the choice may have changed since they last started.
// Texts are looked up in a context with the chosen locale, so the switch does not depend on the system's
// language. Layout direction follows the chosen locale (right-to-left for Arabic).
public class Lang {
    // index 0 = System default: keep the phone's configuration
    static final String[] CODES = { "auto", "ar", "en" };
    static final String[] NAME_KEYS = { "lang_auto", "lang_ar", "lang_en" };

    private static Context app;        // application context: never an Activity (no leaks)
    private static Context localized;  // app, or app with the chosen locale
    private static int cur = 0;

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("lang", Context.MODE_PRIVATE); }

    static int indexOf(String code) {
        for (int i = 0; i < CODES.length; i++) if (CODES[i].equals(code)) return i;
        return -1;
    }

    static void init(Context c) {
        app = c.getApplicationContext();
        int i = indexOf(prefs(app).getString("code", "auto"));
        cur = i < 0 ? 0 : i;
        localized = localize(app, cur);
    }

    private static Context localize(Context base, int i) {
        if (i == 0) return base;
        Configuration cfg = new Configuration(base.getResources().getConfiguration());
        cfg.setLocale(new Locale(CODES[i]));
        return base.createConfigurationContext(cfg);
    }

    static int index() { return cur; }

    static void set(Context c, int i) {
        prefs(c).edit().putString("code", CODES[i]).apply();
        init(c);
    }

    static boolean rtl() {
        return localized.getResources().getConfiguration().getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
    }

    static void apply(View v) {
        v.setLayoutDirection(rtl() ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
    }

    // a text from strings.xml by its key; the key itself if there is no such text
    static String t(String key) {
        int id = localized.getResources().getIdentifier(key, "string", app.getPackageName());
        return id == 0 ? key : localized.getString(id);
    }

    // a text with arguments (%s / %d placeholders, in order)
    static String f(String key, Object... args) {
        int id = localized.getResources().getIdentifier(key, "string", app.getPackageName());
        return id == 0 ? key : localized.getString(id, args);
    }

    static String[] arr(String... keys) {
        String[] r = new String[keys.length];
        for (int i = 0; i < keys.length; i++) r[i] = t(keys[i]);
        return r;
    }
}
