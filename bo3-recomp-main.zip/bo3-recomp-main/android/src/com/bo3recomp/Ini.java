package com.bo3recomp;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

// Reads / changes single keys of bo3recomp.ini (video_options.cpp owns the file; the game rewrites it whole
// when it saves its own options). Used by the launcher settings, which run while no game is open.
// A key that is missing goes right under its [section] header, never at the end of the file (the game keeps
// every line after the last section it does not know, so a stray key there would override the real one).
final class Ini {
    static File file(Context c) { return new File(Installer.dataDir(c), "bo3recomp.ini"); }

    static List<String> read(Context c) {
        try { return new ArrayList<>(Files.readAllLines(file(c).toPath(), StandardCharsets.UTF_8)); }
        catch (Exception e) { return new ArrayList<>(); }
    }

    static String get(Context c, String key, String def) {
        for (String l : read(c)) {
            String t = l.trim();
            if (t.startsWith(key + "=")) return t.substring(key.length() + 1).trim();
        }
        return def;
    }

    static float getFloat(Context c, String key, float def) {
        try { return Float.parseFloat(get(c, key, "")); } catch (Exception e) { return def; }
    }

    static int getInt(Context c, String key, int def) {
        try { return Integer.parseInt(get(c, key, "")); } catch (Exception e) { return def; }
    }

    static void set(Context c, String section, String key, String value) {
        List<String> lines = read(c);
        boolean done = false;
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).trim().startsWith(key + "=")) { lines.set(i, key + "=" + value); done = true; }
        }
        if (!done) {
            int at = -1;
            for (int i = 0; i < lines.size(); i++) if (lines.get(i).trim().equals("[" + section + "]")) { at = i; break; }
            if (at >= 0) lines.add(at + 1, key + "=" + value);
            else { lines.add(0, key + "=" + value); lines.add(0, "[" + section + "]"); }
        }
        try (Writer w = new OutputStreamWriter(new FileOutputStream(file(c)), StandardCharsets.UTF_8)) {
            for (String l : lines) w.write(l + "\n");
        } catch (Exception e) {
            android.util.Log.w("BO3", "ini: " + e);
        }
    }
}
