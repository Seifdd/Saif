package com.bo3recomp;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

// Settings from the start screen, for before the game: quick presets, resolution with - / + , FPS limit,
// shadows, on-screen controller and the video driver. Everything is saved as it changes: the video options
// into bo3recomp.ini (the same file the in-game options use), the controller into its preferences.
public class SettingsActivity extends Activity {
    static final int BG = OptionsPanel.BG, CHIP = OptionsPanel.CHIP, LINE = OptionsPanel.LINE, TEXT = OptionsPanel.TEXT,
        SUB = OptionsPanel.SUB, ACCENT = OptionsPanel.ACCENT;

    // presets: render scale, shadows (1 high), light shaders, FPS limit
    static final float[] P_SCALE = { 0.5f, 0.75f, 1f };
    static final int[] P_SHADOWS = { 0, 0, 1 };
    static final int[] P_LITE = { 1, 0, 0 };
    static final int[] P_FPS = { 60, 60, 60 };

    OptionsPanel ui;
    float scale;
    int fps, shadows, lite, pad;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        Lang.init(this);
        ui = new OptionsPanel(this, new float[6]);
        scale = Ini.getFloat(this, "render_scale", 1f);
        fps = Ini.getInt(this, "fps_limit", 60);
        shadows = Ini.getInt(this, "shadows", 1);
        lite = Ini.getInt(this, "lite_shaders", 0);
        pad = Ini.getInt(this, "virtual_pad", 1);
        build();
    }

    void save() {
        Ini.set(this, "video", "render_scale", String.valueOf(scale));
        Ini.set(this, "video", "fps_limit", String.valueOf(fps));
        Ini.set(this, "video", "shadows", String.valueOf(shadows));
        Ini.set(this, "video", "lite_shaders", String.valueOf(lite));
        Ini.set(this, "input", "virtual_pad", String.valueOf(pad));
    }

    int nearestScale() {
        int best = 0;
        for (int i = 1; i < OptionsPanel.SCALES.length; i++)
            if (Math.abs(OptionsPanel.SCALES[i] - scale) < Math.abs(OptionsPanel.SCALES[best] - scale)) best = i;
        return best;
    }

    void build() {
        final int d = Math.round(getResources().getDisplayMetrics().density);
        ScrollView sv = new ScrollView(this);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[] { Color.rgb(28, 20, 16), BG, BG }));
        LinearLayout outer = new LinearLayout(this);
        outer.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(20 * d, 28 * d, 20 * d, 28 * d);
        outer.addView(col, new LinearLayout.LayoutParams(Math.min(getResources().getDisplayMetrics().widthPixels, 640 * d), ViewGroup.LayoutParams.WRAP_CONTENT));
        sv.addView(outer);

        TextView kicker = ui.text("BO3 RECOMP", 12, ACCENT, true);
        kicker.setLetterSpacing(0.12f);
        col.addView(kicker);
        col.addView(ui.text(Lang.t("settings_btn"), 28, TEXT, true));

        // quick presets
        LinearLayout sp = ui.section(col, Lang.t("preset_title"), Lang.t("preset_hint"));
        int sel = -1;
        for (int i = 0; i < P_SCALE.length; i++)
            if (Math.abs(P_SCALE[i] - scale) < 0.01f && P_SHADOWS[i] == shadows && P_LITE[i] == lite && P_FPS[i] == fps) sel = i;
        ui.addSpaced(sp, ui.chips(Lang.arr("preset_perf", "preset_bal", "preset_qual"), null, sel, i -> {
            scale = P_SCALE[i]; shadows = P_SHADOWS[i]; lite = P_LITE[i]; fps = P_FPS[i];
            save();
            build();
        }));

        // resolution: - / +
        LinearLayout rs = ui.section(col, Lang.t("res_title"), Lang.t("res_hint"));
        final int si = nearestScale();
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView minus = stepButton("\u2212", si > 0);
        TextView plus = stepButton("+", si < OptionsPanel.SCALES.length - 1);
        TextView value = ui.text(Math.round(OptionsPanel.SCALES[si] * 100) + "%  \u00b7  " + OptionsPanel.res(OptionsPanel.SCALES[si]), 18, TEXT, true);
        value.setGravity(Gravity.CENTER);
        row.addView(minus, new LinearLayout.LayoutParams(56 * d, 48 * d));
        row.addView(value, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(plus, new LinearLayout.LayoutParams(56 * d, 48 * d));
        ui.addSpaced(rs, row);
        minus.setOnClickListener(v -> { if (si > 0) { scale = OptionsPanel.SCALES[si - 1]; save(); build(); } });
        plus.setOnClickListener(v -> { if (si < OptionsPanel.SCALES.length - 1) { scale = OptionsPanel.SCALES[si + 1]; save(); build(); } });

        // FPS limit
        LinearLayout fl = ui.section(col, Lang.t("fps_limit"), Lang.t("fps_limit_hint"));
        int fsel = -1;
        String[] ll = new String[OptionsPanel.LIMITS.length];
        for (int i = 0; i < ll.length; i++) { ll[i] = String.valueOf(OptionsPanel.LIMITS[i]); if (OptionsPanel.LIMITS[i] == fps) fsel = i; }
        ui.addSpaced(fl, ui.chips(ll, null, fsel, i -> { fps = OptionsPanel.LIMITS[i]; save(); }));

        // shadows
        LinearLayout sh = ui.section(col, Lang.t("shadows"), Lang.t("shadows_hint"));
        ui.addSpaced(sh, ui.chips(Lang.arr("low", "high"), null, shadows != 0 ? 1 : 0, i -> { shadows = i; save(); }));

        // light shaders
        final OptionsPanel.Toggle liteSw = ui.toggle(col, Lang.t("lite"), Lang.t("lite_hint"), lite != 0);
        liteSw.onChange = () -> { lite = liteSw.isChecked() ? 1 : 0; save(); };

        // on-screen controller
        final OptionsPanel.Toggle padSw = ui.toggle(col, Lang.t("pad"), Lang.t("pad_hint"), pad != 0);
        padSw.onChange = () -> { pad = padSw.isChecked() ? 1 : 0; save(); };
        final int[] pc = { VirtualPad.layoutChoice(this), VirtualPad.sensChoice(this), VirtualPad.opacityChoice(this) };
        LinearLayout pl = ui.section(col, Lang.t("pad_layout"), Lang.t("pad_layout_hint"));
        ui.addSpaced(pl, ui.chips(Lang.arr("lay_classic", "lay_comp", "lay_custom"), null, pc[0], i -> { pc[0] = i; VirtualPad.save(this, pc[0], pc[1], pc[2]); }));
        ui.addSpaced(pl, ui.text(Lang.t("sens"), 14, SUB, true));
        ui.addSpaced(pl, ui.chips(Lang.arr("sens_low", "sens_mid", "sens_high", "sens_vhigh"), null, pc[1], i -> { pc[1] = i; VirtualPad.save(this, pc[0], pc[1], pc[2]); }));
        ui.addSpaced(pl, ui.text(Lang.t("opacity"), 14, SUB, true));
        ui.addSpaced(pl, ui.chips(VirtualPad.OPACITY_NAMES, null, pc[2], i -> { pc[2] = i; VirtualPad.save(this, pc[0], pc[1], pc[2]); }));
        ui.addSpaced(pl, ui.text(Lang.t("edit_pad_note"), 12, SUB, false));

        // video driver
        final String customName = GpuSettings.customName(this);
        final String[] drivers = customName != null ? new String[] { GpuSettings.AUTO, GpuSettings.TURNIP, GpuSettings.STOCK, GpuSettings.CUSTOM }
                                                    : OptionsPanel.DRIVERS;
        final String[] names = customName != null ? new String[] { Lang.t("drv_auto"), "Turnip", Lang.t("drv_phone"), Lang.t("custom") }
                                                  : new String[] { Lang.t("drv_auto"), "Turnip", Lang.t("drv_phone") };
        int dsel = 0;
        String cur = GpuSettings.choice(this);
        for (int i = 0; i < drivers.length; i++) if (drivers[i].equals(cur)) dsel = i;
        LinearLayout dv = ui.section(col, Lang.t("driver"), Lang.t("driver_hint"));
        ui.addSpaced(dv, ui.chips(names, null, dsel, i -> GpuSettings.set(this, drivers[i])));

        // error reports
        Boolean consent = LogUpload.consent(this);
        final OptionsPanel.Toggle logSw = ui.toggle(col, Lang.t("errlog"), Lang.t("errlog_hint"), consent == null || consent);
        logSw.onChange = () -> LogUpload.setConsent(this, logSw.isChecked());

        // done
        TextView ok = ui.text(Lang.t("done"), 17, Color.WHITE, true);
        ok.setGravity(Gravity.CENTER);
        ok.setPadding(0, 15 * d, 0, 15 * d);
        ok.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.argb(70, 255, 255, 255)), ui.round(ACCENT, 14, 0), ui.round(Color.WHITE, 14, 0)));
        ok.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        op.topMargin = 18 * d;
        col.addView(ok, op);

        Lang.apply(sv);
        setContentView(sv);
    }

    TextView stepButton(String s, boolean enabled) {
        TextView t = ui.text(s, 26, TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.argb(60, 255, 255, 255)), ui.round(CHIP, 14, LINE), ui.round(Color.WHITE, 14, 0)));
        t.setEnabled(enabled);
        t.setAlpha(enabled ? 1f : 0.35f);
        return t;
    }
}
